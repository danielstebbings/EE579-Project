#include "dl_base_mul2d.hpp"

#include "dl_base_activate_output.hpp"
#include "dl_base_isa.hpp"

namespace dl {
namespace base {
template <typename feature_t, typename buffer_t>
inline void mul2d_11c(feature_t *output_ptr,
                      feature_t *input0_ptr,
                      feature_t *input1_ptr,
                      const arithArgsType<feature_t> &args)
{
    buffer_t buffer;
    for (size_t output_c = 0; output_c < args.channel; output_c++) // C
    {
        buffer = (buffer_t)input0_ptr[output_c] * (buffer_t)input1_ptr[output_c];
        buffer = DL_RIGHT_SHIFT(buffer, args.mul_shift);
        tool::truncate(output_ptr[output_c], buffer);
    }
}

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// specialize mul2d<int16_t>
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
inline void load_mul2d_11c_s16(arith_i_impl_func_s16_t &i_impl_func,
                               arith_c_impl_func_s16_t &c_impl_func,
                               arith_n_wise_tail_s16_t &n_wise_tail,
                               const arithArgsType<int16_t> &args)
{
#if CONFIG_ESP32P4_BOOST
    if (args.input0_x_offset % 8 == 0 && args.input1_x_offset % 8 == 0 && args.output_x_offset % 8 == 0 &&
        !((unsigned)&args.input0_element[0] & 15) && !((unsigned)&args.input1_element[0] & 15) &&
        !((unsigned)&args.output_element[0] & 15)) {
        switch (args.activation_type) {
        case Linear:
            i_impl_func = dl_esp32p4_s16_mul2d_11c;
            break;
        case ReLU:
        case LeakyReLU:
            i_impl_func = dl_esp32p4_s16_mul2d_11c_relu;
            break;
        case PReLU:
            i_impl_func = dl_esp32p4_s16_mul2d_11c_prelu;
            break;
        }
    } else {
        switch (args.activation_type) {
        case Linear:
            i_impl_func = dl_esp32p4_s16_unaligned_mul2d_11c;
            break;
        case ReLU:
        case LeakyReLU:
            i_impl_func = dl_esp32p4_s16_unaligned_mul2d_11c_relu;
            break;
        case PReLU:
            i_impl_func = dl_esp32p4_s16_unaligned_mul2d_11c_prelu;
            break;
        }
    }
#elif CONFIG_TIE728_BOOST
    if (args.input0_x_offset % 8 == 0 && args.input1_x_offset % 8 == 0 && args.output_x_offset % 8 == 0 &&
        !((unsigned)&args.input0_element[0] & 15) && !((unsigned)&args.input1_element[0] & 15) &&
        !((unsigned)&args.output_element[0] & 15)) {
        switch (args.activation_type) {
        case Linear:
            i_impl_func = dl_tie728_s16_mul2d_11c;
            break;
        case ReLU:
        case LeakyReLU:
            i_impl_func = dl_tie728_s16_mul2d_11c_relu;
            break;
        case PReLU:
            i_impl_func = dl_tie728_s16_mul2d_11c_prelu;
            break;
        }
    } else {
        switch (args.activation_type) {
        case Linear:
            i_impl_func = dl_tie728_s16_unaligned_mul2d_11c;
            break;
        case ReLU:
        case LeakyReLU:
            i_impl_func = dl_tie728_s16_unaligned_mul2d_11c_relu;
            break;
        case PReLU:
            i_impl_func = dl_tie728_s16_unaligned_mul2d_11c_prelu;
            break;
        }
    }
#else
    c_impl_func = mul2d_11c<int16_t, int32_t>;

    switch (args.activation_type) {
    case Linear:
        n_wise_tail = NULL;
        break;
    case ReLU:
        n_wise_tail = arith_output_relu<int16_t, int32_t>;
        break;
    case LeakyReLU:
        n_wise_tail = arith_output_leakyrelu<int16_t, int32_t>;
        break;
    case PReLU:
        n_wise_tail = arith_output_prelu<int16_t, int32_t>;
        break;
    }
#endif // CONFIG_TIE728_BOOST
}

template <>
void mul2d<int16_t>(void *const args_ptr)
{
    const arithArgsType<int16_t> &args = *((arithArgsType<int16_t> *)args_ptr);

    arith_i_impl_func_s16_t i_impl_func = NULL;
    arith_c_impl_func_s16_t c_impl_func = NULL;
    arith_n_wise_tail_s16_t n_wise_tail = NULL;

#if CONFIG_ESP32P4_BOOST
    dl_esp32p4_cfg_round(ROUND_MODE_HALF_EVEN);
#endif
    load_mul2d_11c_s16(i_impl_func, c_impl_func, n_wise_tail, args);

    arith_operation_shell<int16_t>(args, i_impl_func, c_impl_func, n_wise_tail);
}

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// specialize mul2d<int8_t>
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
inline void load_mul2d_11c_s8(arith_i_impl_func_s8_t &i_impl_func,
                              arith_c_impl_func_s8_t &c_impl_func,
                              arith_n_wise_tail_s8_t &n_wise_tail,
                              const arithArgsType<int8_t> &args)
{
#if CONFIG_ESP32P4_BOOST
    if (args.input0_x_offset % 16 == 0 && args.input1_x_offset % 16 == 0 && args.output_x_offset % 16 == 0 &&
        !((unsigned)&args.input0_element[0] & 15) && !((unsigned)&args.input1_element[0] & 15) &&
        !((unsigned)&args.output_element[0] & 15)) {
        switch (args.activation_type) {
        case Linear:
            i_impl_func = dl_esp32p4_s8_mul2d_11c;
            break;
        case ReLU:
        case LeakyReLU:
            i_impl_func = dl_esp32p4_s8_mul2d_11c_relu;
            break;
        case PReLU:
            i_impl_func = dl_esp32p4_s8_mul2d_11c_prelu;
            break;
        }
    } else {
        switch (args.activation_type) {
        case Linear:
            i_impl_func = dl_esp32p4_s8_unaligned_mul2d_11c;
            break;
        case ReLU:
        case LeakyReLU:
            i_impl_func = dl_esp32p4_s8_unaligned_mul2d_11c_relu;
            break;
        case PReLU:
            i_impl_func = dl_esp32p4_s8_unaligned_mul2d_11c_prelu;
            break;
        }
    }
#elif CONFIG_TIE728_BOOST
    if (args.input0_x_offset % 16 == 0 && args.input1_x_offset % 16 == 0 && args.output_x_offset % 16 == 0 &&
        !((unsigned)&args.input0_element[0] & 15) && !((unsigned)&args.input1_element[0] & 15) &&
        !((unsigned)&args.output_element[0] & 15)) {
        switch (args.activation_type) {
        case Linear:
            i_impl_func = dl_tie728_s8_mul2d_11c;
            break;
        case ReLU:
        case LeakyReLU:
            i_impl_func = dl_tie728_s8_mul2d_11c_relu;
            break;
        case PReLU:
            i_impl_func = dl_tie728_s8_mul2d_11c_prelu;
            break;
        }
    } else {
        switch (args.activation_type) {
        case Linear:
            i_impl_func = dl_tie728_s8_unaligned_mul2d_11c;
            break;
        case ReLU:
        case LeakyReLU:
            i_impl_func = dl_tie728_s8_unaligned_mul2d_11c_relu;
            break;
        case PReLU:
            i_impl_func = dl_tie728_s8_unaligned_mul2d_11c_prelu;
            break;
        }
    }
#else
    c_impl_func = mul2d_11c<int8_t, int16_t>;

    switch (args.activation_type) {
    case Linear:
        n_wise_tail = NULL;
        break;
    case ReLU:
        n_wise_tail = arith_output_relu<int8_t, int16_t>;
        break;
    case LeakyReLU:
        n_wise_tail = arith_output_leakyrelu<int8_t, int16_t>;
        break;
    case PReLU:
        n_wise_tail = arith_output_prelu<int8_t, int16_t>;
        break;
    }
#endif // CONFIG_TIE728_BOOST
}

template <>
void mul2d<int8_t>(void *const args_ptr)
{
    const arithArgsType<int8_t> &args = *((arithArgsType<int8_t> *)args_ptr);

    arith_i_impl_func_s8_t i_impl_func = NULL;
    arith_c_impl_func_s8_t c_impl_func = NULL;
    arith_n_wise_tail_s8_t n_wise_tail = NULL;

#if CONFIG_ESP32P4_BOOST
    dl_esp32p4_cfg_round(ROUND_MODE_HALF_EVEN);
#endif
    load_mul2d_11c_s8(i_impl_func, c_impl_func, n_wise_tail, args);

    arith_operation_shell<int8_t>(args, i_impl_func, c_impl_func, n_wise_tail);
}
} // namespace base
} // namespace dl
