#pragma once
#include <string>

namespace dl {
namespace cls {
typedef struct {
    const char *cat_name;
    float score;
} result_t;

} // namespace cls
} // namespace dl
